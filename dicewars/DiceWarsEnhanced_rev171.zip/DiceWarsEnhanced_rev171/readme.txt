date: 	10.04.2007

project:	Dice Wars Enhanced

who: 		DR0ID
		IRC: 	      freenode  #pygame
		homepage: 	http://www.mypage.bluewin.ch/DR0ID/index.html 
	
artwork: 	DR0ID (if any)

how to run: run_game.py
			
								
licenses: 	contact me

dependecies:pyhton 2.4 (www.python.org), pygame 1.7.1 (www.pygame.org)

comments:	very, very beta state, far way from complete

instuctions:
            Right click to end turn.
            Left click to select a land of your color, but only if you have more than one dice on it
            (the numbers in the land represents the number of dices in that land). 
            Then click on a adjectant land to attack (different color of course).The dices will be rolled, 
            if the attacker has more pips than the defender, then the land will be conquered, 
            otherwise you lose all dices in that land.
 
            Have fun!
