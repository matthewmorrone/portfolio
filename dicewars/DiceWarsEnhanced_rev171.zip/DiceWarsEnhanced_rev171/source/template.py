#!/usr/bin/env python
#
#Copyright 2006 DR0ID <dr0id@bluewin.ch> http://mypage.bluewin.ch/DR0ID
#
#
#

"""
#TODO: documentation!
"""

__author__    = "$Author: DR0ID $"
__version__   = "$Revision: 120 $"
__date__      = "$Date: 2007-03-15 09:01:25 +0100 (Do, 15 Mrz 2007) $"
__license__   = ''
__copyright__ = "DR0ID (c) 2007"


